#!/system/bin/sh
MODDIR=${0%/*}
sleep 30
$MODDIR/system/IEMP_Client
